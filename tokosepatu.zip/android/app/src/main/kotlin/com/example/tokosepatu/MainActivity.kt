package com.example.tokosepatu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
